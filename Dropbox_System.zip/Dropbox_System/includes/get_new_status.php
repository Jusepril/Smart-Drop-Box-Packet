<?php
include 'kon_baru.php';

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $searchResi = $_POST['search']; // Ambil data nomor resi dari POST
    
    // Memastikan input tidak kosong
    if (!empty($searchResi)) {
        // Menggunakan prepared statements untuk mencegah SQL Injection
        $stmt = $conn->prepare("
            SELECT r.no_resi, r.nama_penerima, r.contact_penerima, r.tanggal_pengiriman,
            a.activity AS status,
            a.timestamp
            FROM activity_log r
            JOIN (
                SELECT no_resi, activity, timestamp
                FROM activity_log
                WHERE (no_resi, timestamp) IN (
                    SELECT no_resi, MAX(timestamp)
                    FROM activity_log
                    GROUP BY no_resi
                )
            ) a ON r.no_resi = a.no_resi
            WHERE r.no_resi = ?
        ");

        // Mengikat parameter dan mengeksekusi query
        $stmt->bind_param("s", $searchResi);
        $stmt->execute();

        // Mengambil hasil
        $result = $stmt->get_result();

        $waybills = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $waybills[] = [
                    'resiNumber' => $row['no_resi'],
                    'customerName' => $row['nama_penerima'],
                    'customerContact' => $row['contact_penerima'],
                    'deliveryDate' => $row['tanggal_pengiriman'],
                    'status' => $row['status'], // Mengambil aktivitas terbaru
                    'timestamp' => $row['timestamp']
                ];
            }
        }

        // Mengeluarkan data dalam format JSON
        echo json_encode($waybills);

        // Menutup statement
        $stmt->close();
    } else {
        echo json_encode([]);
    }
}

// Menutup koneksi
$conn->close();
?>
