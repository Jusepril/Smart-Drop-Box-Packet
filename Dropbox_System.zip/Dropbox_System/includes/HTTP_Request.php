<?php
include 'kon_baru.php';
require_once '../vendor/autoload.php';

use Twilio\Rest\Client;
use Twilio\Exceptions\TwilioException;

$sid    = "ACb34d1f65e01f07fd9e5d7321f5928635";
$token  = "7f4691ae5612ed480b4842c9341fe5bc";
$twilio = new Client($sid, $token);

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['barcode'])) {
        $barcode = trim($_POST['barcode']);

        // Logika untuk memeriksa apakah barcode sudah diterima
        $stmt = $conn->prepare("SELECT status FROM activity_log WHERE no_resi = ? ORDER BY timestamp DESC LIMIT 1");
        $stmt->bind_param("s", $barcode);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if ($row['status'] == 'diterima') {
                echo "barcode sudah diterima";
            } else {
                // status diupdate ke 'diterima' jika status masih terdaftar
                $stmtUpdate = $conn->prepare("UPDATE activity_log SET status = 'diterima', activity = 'Telah Sampai' WHERE no_resi = ?");
                $stmtUpdate->bind_param("s", $barcode);
                $stmtUpdate->execute();
                $stmtUpdate->close();
                
                $stmtResi = $conn->prepare("SELECT contact_penerima FROM activity_log WHERE no_resi = ?");
                $stmtResi->bind_param("s", $barcode);
                $stmtResi->execute();
                $resultResi = $stmtResi->get_result();
                
                if ($resultResi->num_rows > 0) {
                    $rowResi = $resultResi->fetch_assoc();
                    $recipientNumber = $rowResi['contact_penerima'];
                    
                    $messageContent = "Paket dengan resi $barcode telah diterima.";
                    
                    try {
                        $message = $twilio->messages
                                          ->create("whatsapp:$recipientNumber", 
                                                   [
                                                       "from" => "whatsapp:+14155238886", 
                                                       "body" => $messageContent
                                                   ]
                                          );
                                          echo "data ada";
                    } catch (Exception $e) {
                        echo "data ada";
                        echo "Pesan gagal dikirim ke $recipientNumber: " . $e->getMessage();
                    }
                } else {
                    echo "data tidak ada";
                }
                
                $stmtResi->close();
            }
        } else {
            echo "data tidak ada";
        }

        $stmt->close();
    } else {
        echo "No barcode provided";
    }
} else {
    echo "Invalid request method";
}

$conn->close();
?>
