<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Dropbox System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-top: 50px;
            text-align: center;
        }
        .btn {
            margin: 10px;
        }
        .alert {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 20px;
            margin: 20px 0;
        }
        .alert-icon {
            font-size: 50px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <?php
    include "../includes/kon_baru.php";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Ambil data dari form
    $resiNumber = $_POST['resiNumber'];
    $senderName = $_POST['senderName'];
    $senderContact = $_POST['senderContact'];
    $recipientName = $_POST['recipientName'];
    $recipientContact = $_POST['recipientContact'];
    $deliveryDate = $_POST['deliveryDate'];

    // Check if the resiNumber already exists
    $checkResi = "SELECT * FROM activity_log WHERE no_resi = '$resiNumber'";
    $result = $conn->query($checkResi);

    if ($result->num_rows > 0) {
        echo "<div class='alert alert-danger'>";
        echo "<div class='alert-icon'>⚠️</div>";
        echo "<h4 class='text-danger'>Nomor Resi Sudah Terdaftar</h4>";
        echo "<p>Gunakan Nomor Yang Sesuai.</p>";
        echo '<a href="../User/index.php?page=dashboard" class="btn btn-primary">Kembali</a>';
        echo "</div>";
    } else {
        // Mulai transaksi
        $conn->begin_transaction();

        try {
            // Insert data ke dalam tabel activity_log
            $sql = "INSERT INTO activity_log (activity, no_resi, nama_pengirim, contact_pengirim, nama_penerima, contact_penerima, tanggal_pengiriman, status) 
                    VALUES ('Dalam Perjalanan', '$resiNumber', '$senderName', '$senderContact', '$recipientName', '$recipientContact', '$deliveryDate', 'terdaftar')";
            
            if ($conn->query($sql) === TRUE) {
                $conn->commit(); // Komit transaksi jika berhasil
                echo "<div class='alert alert-success'>";
                echo "<h4>New record created successfully</h4>";
                echo "<p>If you want to receive notifications, please register on WhatsApp via the available button.</p>";
                echo "<p>Then type <strong><em>join movement-necessary</em></strong>.</p>";
                echo '<a href="../User/index.php?page=dashboard" class="btn btn-primary">Back to Home Page</a>';
                echo '<a href="https://wa.me/+14155238886?text=join%20movement-necessary%20" class="btn btn-success">Send WhatsApp Notification</a>';
                echo "</div>";
            } else {
                throw new Exception("Error: " . $sql . "<br>" . $conn->error);
            }
        } catch (Exception $e) {
            $conn->rollback(); // Rollback jika terjadi kesalahan
            echo "<div class='alert alert-danger'>";
            echo "<h4>".$e->getMessage()."</h4>";
            echo "</div>";
        }
    }

    $conn->close();
    ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
